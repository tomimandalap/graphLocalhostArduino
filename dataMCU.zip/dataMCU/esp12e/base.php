<?php
// koneksi
$user = 'root';
$pass = '';
$host = 'localhost';
$db   = 'nodemcu';

$conn = mysqli_connect($host, $user, $pass, $db);

// Data for suhu
$query = mysqli_query($conn, "SELECT nilai1 FROM sensor");
$rows0 = array();
$rows0['name'] = 'Suhu';
while ($tmp = mysqli_fetch_array($query)) {
  $rows0['data'][] = $tmp['nilai1'];
}

// Data for humd
// $query = mysqli_query($conn, "SELECT nilai2 FROM sensor");
// $rows1 = array();
// $rows1['name'] = 'Humd';
// while ($tmp = mysqli_fetch_array($query)) {
//   $rows1['data'][] = $tmp['nilai2'];
// }

// Data for temp
// $query = mysqli_query($conn, "SELECT nilai3 FROM sensor");
// $rows2 = array();
// $rows2['name'] = 'Temp';
// while ($tmp = mysqli_fetch_array($query)) {
//   $rows2['data'][] = $tmp['nilai3'];
// }

$tampil = array();
array_push($tampil, $rows0);
// array_push($tampil, $rows1);
// array_push($tampil, $rows2);

print json_encode($tampil, JSON_NUMERIC_CHECK);

mysqli_close($conn);
