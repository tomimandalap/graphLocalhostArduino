<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="css/bootstrap.min.css">

  <!-- refres kontem -->
  <meta http-equiv="refresh" content="10">

  <!-- Bagian css -->
  <link rel="stylesheet" href="css/linestyle.css">
  <title>Line Chart</title>

  <!-- javascrip -->
  <script src="js/jquery-3.3.1.min.js"></script>
  <script type="text/javascript">
    $(function() {
      var chart;
      $(document).ready(function() {
        $.getJSON("base.php", function(json) {

          chart = new Highcharts.Chart({
            chart: {
              renderTo: 'mygraph',
              type: 'line'

            },
            title: {
              text: 'Data Sensor'

            },
            subtitle: {
              text: 'DHT11 & DS18B20'

            },
            xAxis: {

              title: {
                text: 'Waktu (detik)'
              },
            },
            yAxis: {
              title: {
                text: 'Temperature (C)'
              },
              plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
              }]
            },
            tooltip: {
              formatter: function() {
                return '<b>' + this.series.name + '</b><br/>' +
                  this.x + ': ' + this.y;
              }
            },
            legend: {
              layout: 'vertical',
              align: 'right',
              verticalAlign: 'top',
              x: -10,
              y: 120,
              borderWidth: 0
            },
            series: json
          });
        });
      });
    });
  </script>
  <script src="js/highcharts.js"></script>
  <script src="js/Exporting.js"></script>

  <style>
    /* styles */
    body {
      font-family: 'Raleway', sans-serif;
      background-image: url('img/bgdata.png');
      background-position: top right;
      background-repeat: no-repeat;
      background-size: 60vmax;
    }
  </style>
</head>

<body>
  <!-- navbar -->
  <div class="container my-4">
    <nav class="navbar navbar-expand-lg navbar-light bg-light custom-nav bg-transparent">
      <a class="navbar-brand" href="index.php"><span><svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-arrow-left-square-fill" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" d="M2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2zm9.5 8.5a.5.5 0 0 0 0-1H5.707l2.147-2.146a.5.5 0 1 0-.708-.708l-3 3a.5.5 0 0 0 0 .708l3 3a.5.5 0 0 0 .708-.708L5.707 8.5H11.5z" />
          </svg></span></a>
      <!-- <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="data.php">Data View</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="https://youtube.com/Duino-Elektronik">Tutorial</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="https://wa.me/c/6281278463898">Catalogue</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="https://wa.me/message/VLGJFGFW6NMNE1">Contact</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="https://www.freepik.com/free-vector/teamwork-landing-page-with-illustration_5526305.htm#page=1&query=landing%20page&position=43">About
              Us</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Login</a>
          </li>
        </ul>
      </div> -->
    </nav>
  </div>
  <!-- akhir navbar -->

  <!--- Bagian Judul-->
  <div class="container" style="margin-top:20px">
    <div class="col-sm-10">
      <div class="panel panel-primary">
        <div class="panel-heading">Line Chart</div>
        <div class="panel-body">
          <div id="mygraph"></div>
        </div>
      </div>
    </div>
  </div>
  <script src="js/highcharts.js"></script>
  <script src="js/jquery-3.3.1.min.js"></script>
  <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
  <script src="js/bootstrap.bundle.min.js">
  </script>
</body>

</html>