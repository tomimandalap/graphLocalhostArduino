<?php
include_once("function.php");
$ok = true;
if (!isset($_GET['nilai1']))
  $ok = false;
if (!isset($_GET['nilai2']))
  $ok = false;
if (!isset($_GET['nilai3']))
  $ok = false;
if (!$ok) {
  print("Salah penggunaan!");
  exit();
}

// $waktu = date("Y-m-d H:i:s");
$waktu  = 'NOW()';
$nilai1 = $_GET['nilai1'];
$nilai2 = $_GET['nilai2'];
$nilai3 = $_GET['nilai3'];

$kirim = "INSERT INTO sensor (waktu, nilai1, nilai2, nilai3)" . "VALUE ( $waktu ,'" . $nilai1 . "','" . $nilai2 . "','" . $nilai3 . "');";
$hasil = mysqli_query($conn, $kirim);
if ($hasil) {
  print("Data berhasil disimpan");
} else {
  print("Data gagal disimpan!");
}
